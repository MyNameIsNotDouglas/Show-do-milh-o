# Show do Milhão - Python + Tkinter

Projeto de um jogo de perguntas e respostas estilo "Show do Milhão", feito em Python com interface gráfica usando Tkinter.

## Funcionalidades

- 17 níveis de dificuldade com perguntas de múltiplas categorias
- Sistema de pontuação e ranking com persistência em arquivo
- Ajuda do público, cartas e universitários
- Timer com barra de progresso
- Modularização completa do código

## Execução

```bash
python main.py
```

## Estrutura

- main.py – inicializa o jogo
- interface.py – lógica e interface do jogo
- perguntas.py – manipulação das perguntas
- ranking.py – funções de ranking (CRUD)
- cores.py – definição de cores
