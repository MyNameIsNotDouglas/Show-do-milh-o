import tkinter as tk
from interface import ShowDoMilhao

if __name__ == "__main__":
    root = tk.Tk()
    app = ShowDoMilhao(root)
    root.mainloop()
